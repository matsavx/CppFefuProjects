//TODO:: 16тиричная система в 10тичную, проверкой символа строки на букву или цифру.
// Описать ошибки.
// Перевод из 10 в другие.
// Интерфейс

#include <iostream>
#include <string>
#include <cmath>

using namespace std;

void toTen(string number, int first_system) {
    bool sign = false; //Знак (отрицательный - true)
    if (number[0] == '-') { //проверка первого элемента строки на наличие минуса
        sign = true; //флаг знака
        number.erase(0,1); //удалить 1 символ начиная с позиции 0
    }
    string str_before_point;
    bool is_double = false;
    int i = 0;
    int count = 0;

    while (i < number.length()) {
        if (number[i] == '.') { //проверка на точку. Если нашли то заходим
            is_double = true;//флаг точки
            i = number.length(); //для выхода из цикла, тк 23 строка - пока i < (длина строки)
            number.erase(0, count+1); //Удаление всех символов строки до точки и + точку
        } else {
            str_before_point = str_before_point + number[i]; //Записываем в новую строку символы начальной строки слева направо
            count++; //Количество символов в whole
            i++; //бегунок по циклу
        }
    }

    if (is_double == true) { //Если флаг точки тру то
        string str_after_point = number; //в number остались только цифры после точки
        int after_point = stoi(str_after_point); //переводим это число
    }

    int before_point = stoi(str_before_point); //перевод из string в int

    int ten_before_point = 0; //Переменная куда мы записываем сумму уравнения перевода

    for (int power = count-1; power >= 0; power--) { //power - переменная степени. Двигаемся от (количество символов числа - 1) до 0 включительно
        ten_before_point = ten_before_point + (floor(before_point/pow(10,power)) * pow(first_system, power)); //прибавляем получившееся в уже посчитанное
        before_point = before_point - (floor(before_point/pow(10,power))*pow(10,power)); //избавляемся от первой цифры числа
    }
    cout << "Наше число = " << ten_before_point << endl;
}

int main() {
    string number;
    int first_system = 0;
    int second_system = 0;
    cout << "Введите число" << endl;
    cin >> number;
    cout << "Введите систему счисления" << endl;
    cin >> first_system;
//    cout << "Введите систему счисления, в которую Вы хотите перевести данное число" << endl;
//    cin >> second_system;
    toTen(number,first_system);
//    if (first_system != 10) {
//        toTen();
//    }
//    toAny();
}
