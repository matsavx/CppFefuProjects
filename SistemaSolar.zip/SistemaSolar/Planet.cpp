#include <iostream>
#include <math.h>
#include <GLUT/glut.h>

#include "Planet.h"
#include "texture.h"
#include "drawCircle.h"

Planet::Planet(string name, double aphelion, double perihelion, double periodOrbital,
                double periodRotation,
                 string texturePath, double tamano, double incline, Planet *sateliteDe):
    texture(new Texture(texturePath)),
    rotation(periodRotation),
    name(name),
    aphelion(aphelion),
    locationActualEje(0),
    perihelion(perihelion),
    periodOrbital(periodOrbital),
    texturePath(texturePath),
    tamano(tamano),
    sateliteDe(sateliteDe),
    inclineZ(incline),
    inclineY(rand() % 180)
{

}

Planet::~Planet() {
    delete texture;
    delete sateliteDe;
}

void Planet::Orbit(double grade, double scaleRotationEje)
{
    locationActualEje += grade * scaleRotationEje / rotation;
    locationActualSystem += grade / (periodOrbital == 0 ? 1 : periodOrbital);

    locationActualSystem = locationActualSystem > 360 ? locationActualSystem - 360 : locationActualSystem;
    locationActualEje = locationActualEje > 360 ? locationActualEje - 360 : locationActualEje;
}

void Planet::Draw()
{
    GLfloat position[] = {-2.0, 0.0, 0.0, 1.0};
    GLfloat ambientLight[] = {0.3, 0.3, 0.3, 1.0};
    
    const double pi = 3.1416;
    const double degreesARadians = 57.29577951;
    double translateSystemX = 0.05 * (aphelion + perihelion);
    double translateSystemZ = 0.05 * (aphelion + perihelion);
    
    if(name == "Sun")
        pX = -2;
    else
        pX = -cos((double)(locationActualSystem / degreesARadians + pi)) * translateSystemX;
    
    pY = 0;
    
    if(sateliteDe == NULL)
        pZ = sin((double)(locationActualSystem / degreesARadians + pi)) * translateSystemZ;
    else
        pZ = sin((double)(locationActualSystem / degreesARadians + pi)) * translateSystemX;
    
    
    if(name == "Sun")
    {
        glLightfv(GL_LIGHT0, GL_POSITION, position);
        glLightfv(GL_LIGHT1, GL_AMBIENT, ambientLight);
    }
    else
    {
        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);

        if(sateliteDe == NULL)
        {
            pX += -(translateSystemX + translateSystemZ) / 3;
        }
    }
    
    if(sateliteDe != NULL)
    {
        glPushMatrix();
        glTranslated(sateliteDe->pX, sateliteDe->pY, sateliteDe->pZ);
    }

    glPushMatrix();
    if(sateliteDe == NULL && name != "Sun")
    {
        glTranslated(-(translateSystemX + translateSystemZ) / 3, 0, 0);
        glScaled(1, 1, translateSystemZ / translateSystemX);
        glRotated(90, 1.0, 0.0, 0.0);

        glDisable(GL_LIGHTING);
        glColor3f(0.1f, 0.3f, 0.5f);
        drawCircle(translateSystemX);
        glColor3f(1.0f, 1.0f, 1.0f);
        glEnable(GL_LIGHTING);

    }
    glPopMatrix();
    
    glPushMatrix();
    if(sateliteDe != NULL)
    {
        glRotated(inclineY, 0, 1, 0);
        glRotated(inclineZ, 1, 0, 0);
    }
    glTranslated(pX, pY, pZ);

    GLUquadric *obj = gluNewQuadric();
    gluQuadricTexture(obj, GL_TRUE);
    glEnable(GL_TEXTURE_2D);
    glRotated(270.0f, 1.0f, 0.0f, 0.0f);
    texture->Bind();
    
    glPushMatrix();
    glRotated(locationActualEje, 0, 0, 1);
    gluSphere(obj, tamano/3, 30, 30);
    glPopMatrix();
    
    glDisable(GL_TEXTURE_2D);
    gluDeleteQuadric(obj);
    
    if(name != "Sun")
    {
        glDisable(GL_LIGHT0);
        glDisable(GL_LIGHTING);
    }
    glPopMatrix();
    
    if(sateliteDe != NULL)
    {
        glPopMatrix();
    }
}