#ifndef Planet_h
#define Planet_h

#include <stdio.h>
#include <string>
#include "texture.h"

using namespace std;

class Planet
{
public:
    double _aphelion;
    float radio = 100.0;
    string name;
    double velocityOrbital;
    double aphelion;
    double perihelion;
    double periodOrbital;
    double rotation;
    double inclineZ;
    double inclineY;
    double tamano;
    double timeDelta;
    
    double locationActualEje;
    double locationActualSystem;
    
    double pX;
    double pY;
    double pZ;
    
    string texturePath;
    GLuint TexturePath;
    Texture *texture;
    Planet *sateliteDe;
    
    Planet(string name, double aphelion, double perihelion, double periodOrbital, double periodRotation,
            const std::string texturePath, double tamano, double incline, Planet *sateliteDe = NULL);
    
    virtual ~Planet();

    void Orbit(double grade, double scaleRotationEje);
    
    void Draw();

private:
    Planet(const Planet& planet) {}
    void operator=(const Planet& planet) {}
    
};

#endif /* Planet_h */
