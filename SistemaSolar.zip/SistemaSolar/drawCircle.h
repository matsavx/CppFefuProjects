#include <math.h>

void drawCircle(float x2){

    int smoothing=180;

    glPushMatrix();
    glScaled(x2, x2, x2);
    glBegin(GL_LINE_LOOP);
    for (int i=0;i<smoothing;++i){
      glVertex2d(cos(2 * i * M_PI/smoothing),sin(2*i*M_PI/smoothing));
    }
    glEnd();
    glPopMatrix();
}