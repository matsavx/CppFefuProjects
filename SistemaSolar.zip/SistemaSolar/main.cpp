#include <iostream>
#include <GLUT/glut.h>
#include <OpenGL/OpenGL.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctime>
#include "List.h"
#include "Planet.h"
#include "Universe.h"

Planet *planetHover;
List<Planet*> *planets;
Universe *universe;

double timeMultiplier = 0.005;
double clockCounter = 0;
double zoom = 10;
double dragX = -1;
double dragY = -20;
double mouseX;
double mouseY;

using namespace std;

void initPlanets();
void menu(unsigned char key);
void initSolarSystem();
void rWin(int w, int h);
void rendering();
void keyMap(unsigned char key);
void focusOnPlanet(int index);
void mouseMovement(int x, int y);
void orbit();
void mouse(int button, int state, int x, int y);

void initPlanets()
{
    planets= new List<Planet*>();

    int scale = 20;

    planets->Add(new Planet("Sun", 0, 0, 0, 20,"textures/2k_sun.jpg", 109/20., 1.0));
    planets->Add(new Planet("Mercury", 7.0*scale, 4.6*scale, 0.24, 58.82, "textures/2k_mercury.jpg", .38, 1.0));
    planets->Add(new Planet("Venus", 10.893*scale, 10.747*scale, 0.61, 243, "textures/2k_venus_atmosphere.jpg", .815, 1.0));
    planets->Add(new Planet("Earth", 15.19*scale, 14.95*scale, 4.15, 1, "textures/Tierra.jpg", 1, 25.0));
    planets->Add(new Planet("Mars", 20.67*scale, 24.92*scale, 1.8821, 1, "textures/2k_mars.jpg", .53, 23.0));
    planets->Add(new Planet("Jupiter", 81.6*scale, 74.05*scale, 11.86, 0.41, "textures/2k_jupiter.jpg", 11, 1));
    planets->Add(new Planet("Saturn", 135.36*scale, 151.3*scale, 29.5, 0.445, "textures/2k_saturn.jpg", 9.13, 23.0));
    planets->Add(new Planet("Uranus", 300.6*scale, 273.5*scale, 84, -0.720, "textures/2k_uranus.jpg", 4, 98));
    planets->Add(new Planet("Neptune", 453.7*scale, 445.9*scale, 164.7, 1, "textures/2k_neptune.jpg", 3.88, 1));
    planets->Add(new Planet("Pluto", 730*scale, 440*scale, 247.68, 6.41, "textures/2k_eris_fictional.jpg", 0.186, 120));

    planets->Add(new Planet("Moon", 8, 8, 0.07, 2.5,"textures/2k_moon.jpg", 0.18, 15.0, planets->Get(3)));
    
    planetHover = planets->Get(0);
}

void menu(unsigned char key) {
    for(int i = 0; i < planets->Length() - 1; i++)
        cout << "Press " << i << " to watch " << planets->Get(i)->name << endl;
    
    cout << "Press W to make zoom in" << endl;
    cout << "Press S to make zoom out" << endl;
    cout << "Press + speed up the time" << endl;
    cout << "Press - speed down the time" << endl;
    cout << "Press and move mouse to rotate the camera" << endl;
    cout << "--------------------------------------" << endl;
    cout << "--------------------------------------" << endl;
    
    if(key >= '0' && key <= planets->Length())
        cout << "This is the " << planets->Get(key - '0')->name;
    
}

void rWin(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(60.0, (GLfloat) w/(GLfloat) h, 1.0, 1500.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void rendering() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    double x, y, z;
    const double halfPI = 3.1416 / 180;
    
    x = sin((-mouseX + dragX) * halfPI) * cos((mouseY - dragY) * halfPI) * zoom;
    y = sin((mouseY - dragY) * halfPI) * zoom;
    z = cos((-mouseX + dragX) * halfPI) * cos((mouseY - dragY) * halfPI) * zoom;
    
    gluLookAt(planetHover->pX + x, planetHover->pY + y, planetHover->pZ + z,
              planetHover->pX, planetHover->pY, planetHover->pZ, 0.0, 1.0, 0.0);
    
    glPushMatrix();
    universe->draw();
    for(int i = 0; i < planets->Length(); i++)
        planets->Get(i)->Draw();
    glPopMatrix();
    
    glutSwapBuffers();
}

void focusOnPlanet(int index) {
    Planet * planet;
    planet = planets->Get(index);
    planetHover = planet;
}

void keyMap(unsigned char key, int A, int B) {
    int number = key - '0';
    switch(key) {
        case 'w': zoom--;
            break;
        case 's': zoom++;
            break;
        case '0': focusOnPlanet(0);
            break;
        case '1': focusOnPlanet(1);
            break;
        case '-': timeMultiplier /= timeMultiplier < 0.001 ? 1 : 2;
            break;
        case '+': timeMultiplier *= timeMultiplier > 10 ? 1 : 2;
            break;
        case 27:  exit(0);
            break;
        default:  break;
    }
    if (number >= 0 && number < 10) {
        planetHover = planets->Get(number);
    }
}

void mouse(int button, int state, int x, int y) {
    switch(button) {

        case 0:
            if(state == 0) {
                if(dragX == -1) {
                    dragX = x;
                    dragY = y;
                }
                else {
                    dragX += x - mouseX;
                    dragY += y - mouseY;
                }
                mouseX = x;
                mouseY = y;
            }
            break;
        case 1:
            break;
        default:
            break;
    }
}

void mouseMovement(int x, int y) {
    mouseX = x;
    mouseY = y;
}

void orbit() {
    long newClockCounter = clock();
    
    for(int i = 0; i < planets->Length(); i++)
        planets->Get(i)->Orbit(timeMultiplier * ((newClockCounter - clockCounter) / 20), 30);
    
    clockCounter = newClockCounter;
    glutPostRedisplay();
}

void initSolarSystem() {
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH | GLUT_MULTISAMPLE);
    glutInitWindowSize(1280, 1024);
    glutCreateWindow("Solar System");
    initPlanets();
    menu(0);
    universe = new Universe("textures/2k_stars+milky_way.jpg", 1200);

    glutReshapeFunc(rWin);
    glutDisplayFunc(rendering);
    glutKeyboardFunc(keyMap);
    glutMotionFunc(mouseMovement);
    glutMouseFunc(mouse);
    
    glEnable(GL_DEPTH_TEST);
    glFrontFace(GL_CCW);
    glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_MULTISAMPLE);
    glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
    glShadeModel(GL_SMOOTH);
    glClearColor(0.0, 0.0, 0.0, 0.0);

    glutIdleFunc(orbit);
    glutMainLoop();
}


int main(int argc, char **argv) {
    glutInit(&argc, argv);
    initSolarSystem();
    return 0;
}