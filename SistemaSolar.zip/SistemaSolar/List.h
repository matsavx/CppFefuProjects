#ifndef List_h
#define List_h

#include <stdio.h>
#include <iostream>

template <class T>
class Node
{
public:
    T value;
    Node* next;
    Node* prev;

    Node();
};

template <class T>
class List
{
public:
    Node<T>* head;
    Node<T>* tail;

    List();

    int Length();

    void Add(T value);

    void AddAfter(T value, int index);

    T Get(int index);

    void RemoveAt(int index);

    void PrintAll(bool reverse = false);
};

using namespace std;

template <class T>
Node<T>::Node()
{
    next = NULL;
    prev = NULL;
}

template <class T>
List<T>::List()
{
    head = NULL;
    tail = NULL;
}

template <class T>
int List<T>::Length()
{
    Node<T>* node = head;
    int cont = 0;
    while(node)
    {
        cont++;
        node = node->next;
    }

    return cont;
}

template <class T>
void List<T>::Add(T value)
{
    Node<T>* node = new Node<T>();
    node->value = value;


    if(!tail)
    {
        head = node;
        tail = node;
    }
    else
    {
        tail->next = node;
        node->prev = tail;
        tail = node;
    }
}

template <class T>
void List<T>::AddAfter(T value, int index)
{
    int length = Length();

    if(length <= index)
        return;

    if(length == index -1)
        Add(value);

    Node<T>* node = head;
    int cont = 0;

    while(cont < index)
    {
        cont++;
        node = node->next;
    }

    Node<T>* n = new Node<T>();
    n->value = value;
    node->next->prev = n;
    n->next = node->next;
    node->next = n;
    n->prev = node;
}

template <class T>
T List<T>::Get(int index)
{
    int length = Length();

    if(length <= index)
        return NULL;

    Node<T>* node = head;
    int cont = 0;

    while(cont < index)
    {
        cont++;
        node = node->next;
    }

    return node->value;
}

template <class T>
void List<T>::RemoveAt(int index)
{
    int length = Length();

    if(length <= index)
        return;

    if(index == 0)
    {
        Node<T>* node = head;
        head = head->next;
        delete node;
        return;
    }

    Node<T>* node = head;
    for(int i = 0; i < index; node = node->next, i++);

    if(index == length - 1)
    {
        node->prev->next;
        delete node;
    }
    else
    {
        node->next->prev = node->prev;
        node->prev->next = node->next;
        delete node;
    }
}

template <class T>
void List<T>::PrintAll(bool reverse)
{
    if(!reverse)
    {
        Node<T>* node = head;
        int i = 0;

        while(node)
        {
            cout << "[" << i++ << "]" << node->value << endl;
            node = node->next;
        }
    }
    else
    {
        Node<T>* node = tail;
        int i = Length() - 1;

        while(node)
        {
            cout << "[" << i-- << "] = " << node->value << endl;
            node = node->prev;
        }
    }
}


#endif /* List_h */